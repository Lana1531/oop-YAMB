#YAMB- konzolna verzija

#OPIS projekta
Projekt implementira popularnu kockarsku igru YAMB kao konzolnu aplikaciju. 
Igra podr�ava 1-2 igra�a s opcijom igranja protiv ra�unala.

#ZNA�AJKE
-Implementacija tablice- 4 stupca i 12 redova
-Sustav bodovanja
-Validacija poteza

#UPUTE ZA POKRETANJE
#Windows
preuzeti 'YAMB.zip'
otvoriti zip i raspakirati
pokreniti 'YAMB.exe'

#Linux
Preuzmite 'YAMB.zip' i raspakirajte
Otvorite terminal u mapi s kodom
Kompajlirajte: 'g++ -o yamb *.cpp'
Pokrenite: './yamb'

#AUTOR
Lana Plazoni�
